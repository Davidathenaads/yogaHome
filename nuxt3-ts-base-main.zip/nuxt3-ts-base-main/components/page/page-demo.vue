<script setup lang="ts">
// PageDemo 請填寫功能描述👈
</script>

<template lang="pug">
#PageDemo
  p PageDemo
</template>

<style lang="scss" scoped>
// 佈局 ----
#PageDemo {
  display: grid;
  grid-template-columns: 1fr;
  grid-template-areas: ' ';
  gap: 10px;
}

// 組件 ----
</style>
