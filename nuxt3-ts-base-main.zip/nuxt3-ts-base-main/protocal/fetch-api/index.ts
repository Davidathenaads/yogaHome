import * as auth from './methods/api/auth';
export default {
  ...auth
};
