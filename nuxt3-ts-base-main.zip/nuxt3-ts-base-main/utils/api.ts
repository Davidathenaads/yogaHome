import api from '@/protocal/fetch-api';
export default api;
