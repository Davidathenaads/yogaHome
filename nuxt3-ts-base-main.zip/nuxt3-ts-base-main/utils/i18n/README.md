// i18n key map
// nuxt i18n 目前版本有問題，暫時用自訂義