<script setup lang="ts">
// posts 請填寫功能描述👈
</script>

<template lang="pug">
#Posts
  p posts
  p {{ $route.params.id }}
</template>
