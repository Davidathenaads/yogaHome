<script setup lang="ts">
// layout
</script>

<template lang="pug">
#layout
  //- p layout
  //- pre(v-for="i of 100" :key="i") {{ "123231212123231212312aa123231212312aa123231212312aa123231212312aa123231212312aa123231212312aa312aa" }}
  //- // TODO check
  NuxtPage
</template>

<style lang="scss">
body {
  background-color: #eee;
}

// 佈局
#layout {
  max-width: 100vw;
  min-height: 100vh;
}

</style>
