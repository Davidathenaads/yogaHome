<script setup lang="ts">
// error-layout 請填寫功能描述👈
</script>

<template lang="pug">
#error-layout
  p error-layout
</template>
