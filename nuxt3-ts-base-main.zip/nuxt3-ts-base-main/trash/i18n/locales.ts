export default {
  '//_key:': ['en', 'zhTw'],
  demo: ['welcome', '你好']
};
