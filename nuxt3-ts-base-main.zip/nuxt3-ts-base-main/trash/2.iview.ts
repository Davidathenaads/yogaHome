// // 1. 引入組件
// import ViewUIPlus from 'view-ui-plus'

// // 2. 引入組件樣式
// import 'view-ui-plus/dist/styles/viewuiplus.css'
// // 3. 註冊
// export default defineNuxtPlugin((nuxtApp) => {
//   nuxtApp.vueApp.use(ViewUIPlus);
// });

