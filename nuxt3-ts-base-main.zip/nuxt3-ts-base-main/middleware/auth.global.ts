export default defineNuxtRouteMiddleware((to, from) => {
  // console.log(to, from);
  // console.log("middleware demo", to, from);
  // if (to.params.id === '1') {
  //   return abortNavigation() // 終止導航
  // }
  // return navigateTo('/') // 導航
});
