// declare module 'js-cookie';
// declare module 'crypto-js';
// declare module 'hqchart';
// declare module 'splitpanes';

// interface Emitter {
//   on<T = any>(type: string, handler?: (event: T) => void): void;
//   off<T = any>(type: string, handler?: (event: T) => void): void;
//   emit<T = any>(type: string, event?: T): void;
// }
// declare module 'mitt' {
//   function mitt(): Emitter;
//   export = mitt;
// }
// // 縮放
// declare interface CSSStyleDeclaration {
//   zoom: string;
// }

