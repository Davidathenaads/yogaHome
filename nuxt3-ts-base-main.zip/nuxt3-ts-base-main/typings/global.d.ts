// import type Echo from 'laravel-echo';
// import $api from '@/protocal/RESTfulApi/methods';

// declare module '@vue/runtime-core' {
//   interface ComponentCustomProperties {
//     $mitt: Emitter;
//     $api: typeof $api
//   }
// }
// declare global {
//   interface Window {
//     Echo?: Echo;
//     TradingView?:TradingView, 
//   }
// }
