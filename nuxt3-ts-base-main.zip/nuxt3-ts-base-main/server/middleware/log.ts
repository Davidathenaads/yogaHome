// https://nuxt.com.cn/docs/guide/directory-structure/server
export default defineEventHandler((_event) => {
  // console.log('New request: ' + event.node.req.url)
});
