## Server API
```
const res = await $fetch('/nuxt/demo/123');
console.log(res);
```