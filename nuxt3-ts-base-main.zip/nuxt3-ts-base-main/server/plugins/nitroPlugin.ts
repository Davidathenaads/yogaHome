export default defineNitroPlugin((_nitroApp) => {
  // console.log('Nitro plugin', nitroApp);
});
